﻿using System;
using System.Drawing;
using System.Windows.Forms;
using System.Net.Http.Headers;
using System.Web;
using System.IO;
using System.Net.Http;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System.Collections.Generic;

namespace FACE
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            
            InitializeComponent();
        }
        

        private void button2_Click(object sender, EventArgs e)
        {
            if (openFileDialog1.ShowDialog() == DialogResult.OK)//버튼을 누르면 새창이 뜨고 거기서 사진을 선택할수있다.
            {
                Bitmap image = new Bitmap(openFileDialog1.FileName);
                pictureBox1.Image = image;//사진을 선택하면 image안에 내가 선택한 사진
                MakeRequest(image); 
            }
        }

        private async void MakeRequest(Bitmap selectedImage)//서버로 선택된 사진을 보내주는 함수
        {

            var client = new HttpClient();
            var queryString = HttpUtility.ParseQueryString(string.Empty);
            var site = "https://api.projectoxford.ai/emotion/v1.0/recognize?" + queryString;


            HttpResponseMessage response = null;
            MemoryStream stream = new MemoryStream();
            ByteArrayContent con = null;

            client.DefaultRequestHeaders.Add("Ocp-Apim-Subscription-Key", "7313fd7c0aa84f72b9b9630a9b58d2a1"); //사이트에서 부여된 key 값 넣어줌
            selectedImage.Save(stream, System.Drawing.Imaging.ImageFormat.Bmp);


            con = new ByteArrayContent(stream.ToArray());
            con.Headers.ContentType = new MediaTypeHeaderValue("application/octet-stream");
            response = await client.PostAsync(site, con);
            con.Dispose();

            MessageBox.Show(response.Content.ReadAsStringAsync().Result);
            
            var json = response;
            var objects = JArray.Parse(response.Content.ReadAsStringAsync().Result); // parse as array  
            foreach (JObject root in objects)
            {
                foreach (KeyValuePair<String, JToken> app in root)
                {

                    Console.WriteLine(objects);
                    

                }
            }


        }


    }
    internal class emotion{}
}
