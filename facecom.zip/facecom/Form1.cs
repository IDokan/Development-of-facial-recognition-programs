﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace facecom
{
    public partial class Form1 : Form
    {
        private object response;

   

        public Form1()
        {
            InitializeComponent();
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                Bitmap image = new Bitmap(openFileDialog1.FileName);
                pictureBox1.Image = image;
                MakeRequest(image);
            }
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                Bitmap image1 = new Bitmap(openFileDialog1.FileName);
                pictureBox1.Image = image1;
                MakeRequest(image1);
            }
        }


    private async void MakeRequest(Bitmap select1)
            {
                var client = new HttpClient();
                var queryString = HttpUtility.ParseQueryString(string.Empty);
                var uri = "https://api.projectoxford.ai/face/v1.0/findsimilars" + queryString;


            client.DefaultRequestHeaders.Add("Ocp-Apim-Subscription-Key", "7313fd7c0aa84f72b9b9630a9b58d2a1");

                queryString["returnFaceId"] = "true";
                queryString["returnFaceLandmarks"] = "false";
                queryString["returnFaceAttributes"] = "{string}";
        
                byte[] byteData = Encoding.UTF8.GetBytes("{body}");

            HttpResponseMessage response;
            
            byte[] byteDatas = Encoding.UTF8.GetBytes("{body}");

            using (var content = new ByteArrayContent(byteData))
            {
                content.Headers.ContentType = new MediaTypeHeaderValue("< your content type, i.e. application/json >");
                response = await client.PostAsync(uri, content);
            }

        }
    }

}









